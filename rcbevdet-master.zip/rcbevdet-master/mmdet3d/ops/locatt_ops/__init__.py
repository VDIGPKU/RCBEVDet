from .locatt import localattention

__all__ = ['localattention']